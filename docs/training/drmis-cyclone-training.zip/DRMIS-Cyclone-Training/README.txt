DRMIS Backend Training: When a Cyclone Strikes

1-Training-Slides.pptx        23 slides with speaker notes (16:9, editable)
2-Exercise-Handout-PRINT.pdf  6 pages, A4. Print one copy per attendee.

RAP repository: https://github.com/DRMIS-VBoS/disaster-project-rap
Backend:        https://drmis.info/admin/
